import System.Environment
import Options.Applicative

data Args = Args {
    player :: [String],
    numPlayers :: Int,
    communityCards :: [String]
} deriving (Show)

parse :: Parser Args
parse = Args
    <$> some (argument str (metavar "PLAYER_CARDS" <> help "two cards"))
    <*> argument auto (metavar "NUM_PLAYERS" <> help "number of players")
    <*> many (argument str (metavar "COMMUNITY_CARDS" <> help "community cards"))

main :: IO ()
main = do
    args <- execParser opts
    
    putStrLn "Player Cards: "
    mapM_ putStrLn (playerCards args)

    putStrLn $ "# of players: " ++ show (numPlayers args)

    putStrLn "Community Cards: "

    mapM_ putStrLn (communityCards args)

    where
        opts = info (parser <**> helper)
            ( fullDesc 
            <> progDesc "Poker hand evaluators"
            <> header "poker-evaluator - evaluate poker hands")

